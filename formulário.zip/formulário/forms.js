function funcao()
{
    alert($("#texto").val() + '\n' + $("#rg").val() + '\n' + $("#cpf").val() + '\n' +  $("#email").val() ) ;
    
}
